"""
app.py
FFC ICT Helpdesk & Asset Management System
--------------------------------------------
A lightweight Flask web application for logging and tracking IT support
tickets and IT assets (servers, network gear, PCs, printers) at a plant
site such as FFC Goth Machhi.

Run:
    pip install -r requirements.txt
    python app.py
Then open http://127.0.0.1:5000 in a browser.

Default login: admin / admin123   (see documentation for the full user list)
"""

import os
from datetime import datetime, timedelta
from functools import wraps

from flask import (
    Flask, render_template, request, redirect, url_for, session, flash, jsonify
)
from werkzeug.security import check_password_hash

import db

app = Flask(__name__)
app.secret_key = os.environ.get("FFC_SECRET_KEY", "dev-secret-key-change-in-production")


# ---------------------------------------------------------------- helpers --

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


def roles_required(*roles):
    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if "user_id" not in session:
                return redirect(url_for("login", next=request.path))
            if session.get("role") not in roles:
                flash("You do not have permission to access that page.", "error")
                return redirect(url_for("dashboard"))
            return view(*args, **kwargs)
        return wrapped
    return decorator


def current_user():
    if "user_id" not in session:
        return None
    return {
        "id": session["user_id"],
        "username": session["username"],
        "full_name": session["full_name"],
        "role": session["role"],
    }


@app.context_processor
def inject_user():
    return {"current_user": current_user()}


# ------------------------------------------------------------------ auth --

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        conn = db.get_conn()
        row = conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        conn.close()
        if row and check_password_hash(row["password_hash"], password):
            session["user_id"] = row["id"]
            session["username"] = row["username"]
            session["full_name"] = row["full_name"]
            session["role"] = row["role"]
            flash(f"Welcome back, {row['full_name']}.", "success")
            return redirect(request.args.get("next") or url_for("dashboard"))
        flash("Invalid username or password.", "error")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("login"))


# --------------------------------------------------------------- dashboard --

@app.route("/")
@login_required
def dashboard():
    conn = db.get_conn()

    total_tickets = conn.execute("SELECT COUNT(*) c FROM tickets").fetchone()["c"]
    open_tickets = conn.execute(
        "SELECT COUNT(*) c FROM tickets WHERE status IN ('Open','In Progress')"
    ).fetchone()["c"]
    critical_tickets = conn.execute(
        "SELECT COUNT(*) c FROM tickets WHERE priority='Critical' AND status NOT IN ('Resolved','Closed')"
    ).fetchone()["c"]
    total_assets = conn.execute("SELECT COUNT(*) c FROM assets").fetchone()["c"]

    status_counts = conn.execute(
        "SELECT status, COUNT(*) c FROM tickets GROUP BY status"
    ).fetchall()

    category_counts = conn.execute(
        "SELECT cat.name, COUNT(*) c FROM tickets t "
        "JOIN categories cat ON cat.id = t.category_id "
        "GROUP BY cat.name ORDER BY c DESC"
    ).fetchall()

    # average resolution time in hours, for resolved/closed tickets
    resolved = conn.execute(
        "SELECT created_at, resolved_at FROM tickets WHERE resolved_at IS NOT NULL"
    ).fetchall()
    if resolved:
        total_hours = 0
        for r in resolved:
            created = datetime.fromisoformat(r["created_at"])
            closed = datetime.fromisoformat(r["resolved_at"])
            total_hours += (closed - created).total_seconds() / 3600
        avg_resolution_hours = round(total_hours / len(resolved), 1)
    else:
        avg_resolution_hours = 0

    recent_tickets = conn.execute(
        "SELECT t.*, cat.name AS category_name FROM tickets t "
        "JOIN categories cat ON cat.id = t.category_id "
        "ORDER BY t.created_at DESC LIMIT 6"
    ).fetchall()

    asset_status_counts = conn.execute(
        "SELECT status, COUNT(*) c FROM assets GROUP BY status"
    ).fetchall()

    conn.close()

    return render_template(
        "dashboard.html",
        total_tickets=total_tickets,
        open_tickets=open_tickets,
        critical_tickets=critical_tickets,
        total_assets=total_assets,
        status_counts=status_counts,
        category_counts=category_counts,
        avg_resolution_hours=avg_resolution_hours,
        recent_tickets=recent_tickets,
        asset_status_counts=asset_status_counts,
    )


@app.route("/api/stats")
@login_required
def api_stats():
    """JSON endpoint feeding the Chart.js graphs on the dashboard."""
    conn = db.get_conn()
    status_counts = conn.execute(
        "SELECT status, COUNT(*) c FROM tickets GROUP BY status"
    ).fetchall()
    category_counts = conn.execute(
        "SELECT cat.name, COUNT(*) c FROM tickets t "
        "JOIN categories cat ON cat.id = t.category_id "
        "GROUP BY cat.name ORDER BY c DESC"
    ).fetchall()
    conn.close()
    return jsonify({
        "status_labels": [r["status"] for r in status_counts],
        "status_values": [r["c"] for r in status_counts],
        "category_labels": [r["name"] for r in category_counts],
        "category_values": [r["c"] for r in category_counts],
    })


# ----------------------------------------------------------------- tickets --

@app.route("/tickets")
@login_required
def tickets_list():
    status_filter = request.args.get("status", "")
    priority_filter = request.args.get("priority", "")
    search = request.args.get("q", "")

    query = (
        "SELECT t.*, cat.name AS category_name FROM tickets t "
        "JOIN categories cat ON cat.id = t.category_id WHERE 1=1"
    )
    params = []
    if status_filter:
        query += " AND t.status = ?"
        params.append(status_filter)
    if priority_filter:
        query += " AND t.priority = ?"
        params.append(priority_filter)
    if search:
        query += " AND (t.subject LIKE ? OR t.requester_name LIKE ?)"
        params.extend([f"%{search}%", f"%{search}%"])
    query += " ORDER BY t.created_at DESC"

    conn = db.get_conn()
    tickets = conn.execute(query, params).fetchall()
    conn.close()

    return render_template(
        "tickets.html", tickets=tickets, status_filter=status_filter,
        priority_filter=priority_filter, search=search,
    )


@app.route("/tickets/new", methods=["GET", "POST"])
@login_required
def ticket_new():
    conn = db.get_conn()
    categories = conn.execute("SELECT * FROM categories ORDER BY name").fetchall()
    assets = conn.execute("SELECT * FROM assets ORDER BY name").fetchall()

    if request.method == "POST":
        conn.execute(
            "INSERT INTO tickets (subject, description, category_id, priority, status, "
            "requester_name, requester_dept, asset_id, created_at) VALUES (?,?,?,?,?,?,?,?,?)",
            (
                request.form["subject"],
                request.form["description"],
                request.form["category_id"],
                request.form["priority"],
                "Open",
                request.form["requester_name"],
                request.form.get("requester_dept", ""),
                request.form.get("asset_id") or None,
                datetime.now().isoformat(),
            ),
        )
        conn.commit()
        conn.close()
        flash("Ticket logged successfully.", "success")
        return redirect(url_for("tickets_list"))

    conn.close()
    return render_template("ticket_form.html", categories=categories, assets=assets)


@app.route("/tickets/<int:ticket_id>")
@login_required
def ticket_detail(ticket_id):
    conn = db.get_conn()
    ticket = conn.execute(
        "SELECT t.*, cat.name AS category_name, a.name AS asset_name, a.asset_tag "
        "FROM tickets t JOIN categories cat ON cat.id = t.category_id "
        "LEFT JOIN assets a ON a.id = t.asset_id WHERE t.id = ?",
        (ticket_id,),
    ).fetchone()
    comments = conn.execute(
        "SELECT * FROM ticket_comments WHERE ticket_id = ? ORDER BY created_at", (ticket_id,)
    ).fetchall()
    staff = conn.execute("SELECT * FROM users WHERE role IN ('staff','admin') ORDER BY full_name").fetchall()
    conn.close()

    if ticket is None:
        flash("Ticket not found.", "error")
        return redirect(url_for("tickets_list"))

    return render_template("ticket_detail.html", ticket=ticket, comments=comments, staff=staff)


@app.route("/tickets/<int:ticket_id>/update", methods=["POST"])
@login_required
def ticket_update(ticket_id):
    status = request.form["status"]
    assigned_to = request.form.get("assigned_to", "")
    resolution_notes = request.form.get("resolution_notes", "")

    conn = db.get_conn()
    resolved_at = None
    if status in ("Resolved", "Closed"):
        existing = conn.execute("SELECT resolved_at FROM tickets WHERE id=?", (ticket_id,)).fetchone()
        resolved_at = existing["resolved_at"] or datetime.now().isoformat()
    conn.execute(
        "UPDATE tickets SET status=?, assigned_to=?, resolution_notes=?, resolved_at=? WHERE id=?",
        (status, assigned_to, resolution_notes, resolved_at, ticket_id),
    )
    conn.commit()
    conn.close()
    flash("Ticket updated.", "success")
    return redirect(url_for("ticket_detail", ticket_id=ticket_id))


@app.route("/tickets/<int:ticket_id>/comment", methods=["POST"])
@login_required
def ticket_comment(ticket_id):
    comment = request.form.get("comment", "").strip()
    if comment:
        conn = db.get_conn()
        conn.execute(
            "INSERT INTO ticket_comments (ticket_id, author, comment, created_at) VALUES (?,?,?,?)",
            (ticket_id, session["full_name"], comment, datetime.now().isoformat()),
        )
        conn.commit()
        conn.close()
        flash("Comment added.", "success")
    return redirect(url_for("ticket_detail", ticket_id=ticket_id))


# ------------------------------------------------------------------ assets --

@app.route("/assets")
@login_required
def assets_list():
    search = request.args.get("q", "")
    status_filter = request.args.get("status", "")

    query = (
        "SELECT a.*, cat.name AS category_name FROM assets a "
        "JOIN categories cat ON cat.id = a.category_id WHERE 1=1"
    )
    params = []
    if search:
        query += " AND (a.name LIKE ? OR a.asset_tag LIKE ? OR a.ip_address LIKE ?)"
        params.extend([f"%{search}%", f"%{search}%", f"%{search}%"])
    if status_filter:
        query += " AND a.status = ?"
        params.append(status_filter)
    query += " ORDER BY a.asset_tag"

    conn = db.get_conn()
    assets = conn.execute(query, params).fetchall()

    # flag assets whose warranty has expired or expires within 90 days
    today = datetime.now().date()
    enriched = []
    for a in assets:
        warranty_flag = None
        if a["warranty_expiry"]:
            exp = datetime.fromisoformat(a["warranty_expiry"]).date()
            if exp < today:
                warranty_flag = "expired"
            elif (exp - today).days <= 90:
                warranty_flag = "expiring_soon"
        enriched.append({**dict(a), "warranty_flag": warranty_flag})
    conn.close()

    return render_template(
        "assets.html", assets=enriched, search=search, status_filter=status_filter
    )


@app.route("/assets/new", methods=["GET", "POST"])
@login_required
def asset_new():
    conn = db.get_conn()
    categories = conn.execute("SELECT * FROM categories ORDER BY name").fetchall()

    if request.method == "POST":
        conn.execute(
            "INSERT INTO assets (asset_tag, name, category_id, ip_address, location, status, "
            "purchase_date, warranty_expiry, assigned_to, notes) VALUES (?,?,?,?,?,?,?,?,?,?)",
            (
                request.form["asset_tag"], request.form["name"], request.form["category_id"],
                request.form.get("ip_address", ""), request.form.get("location", ""),
                request.form["status"], request.form.get("purchase_date") or None,
                request.form.get("warranty_expiry") or None,
                request.form.get("assigned_to", ""), request.form.get("notes", ""),
            ),
        )
        conn.commit()
        conn.close()
        flash("Asset added to inventory.", "success")
        return redirect(url_for("assets_list"))

    conn.close()
    return render_template("asset_form.html", categories=categories)


@app.route("/assets/<int:asset_id>")
@login_required
def asset_detail(asset_id):
    conn = db.get_conn()
    asset = conn.execute(
        "SELECT a.*, cat.name AS category_name FROM assets a "
        "JOIN categories cat ON cat.id = a.category_id WHERE a.id = ?",
        (asset_id,),
    ).fetchone()
    tickets = conn.execute(
        "SELECT * FROM tickets WHERE asset_id = ? ORDER BY created_at DESC", (asset_id,)
    ).fetchall()
    conn.close()

    if asset is None:
        flash("Asset not found.", "error")
        return redirect(url_for("assets_list"))

    return render_template("asset_detail.html", asset=asset, tickets=tickets)


# -------------------------------------------------------------------- main --

if __name__ == "__main__":
    db.init_db()
    app.run(debug=True, host="0.0.0.0", port=5000)
