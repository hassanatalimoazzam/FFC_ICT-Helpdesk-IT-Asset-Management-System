# FFC ICT Helpdesk & Asset Management System

A lightweight, self-contained web application for logging IT support
tickets and tracking IT assets (servers, network devices, PCs, printers)
at an FFC plant site such as Goth Machhi.

Built with **Python (Flask) + SQLite** on the backend and **server-rendered
HTML/CSS + Chart.js** on the frontend — no external services, no internet
connection required after installation, and no license costs.

See `FFC_ICT_Helpdesk_System_Documentation.docx` (provided alongside this
folder) for the full project write-up: objectives, architecture, ER
diagram, module descriptions and screenshots.

## Features

- **Ticket management** — log, filter, search, assign, comment on and
  resolve ICT support tickets, with priority and SLA-style resolution
  time tracking.
- **Asset inventory** — register servers, network gear, PCs and printers
  with IP address, location, status and warranty date; automatic flags
  for assets whose warranty has expired or is expiring within 90 days.
- **Dashboard** — live counts (total/open/critical tickets, average
  resolution time) plus category and status charts, rendered with a
  locally bundled copy of Chart.js (works fully offline).
- **Role-aware login** — admin / IS staff / end-user accounts (see demo
  credentials below).
- **Linked records** — a ticket can be tied to the specific asset it
  concerns, and an asset's page shows its full ticket history.

## Requirements

- Python 3.9+
- pip

## Setup

```bash
cd FFC_ICT_Helpdesk_System
pip install -r requirements.txt
python app.py
```

The app initialises `ffc_helpdesk.db` (SQLite) and seeds it with demo
categories, users, assets and tickets the first time it runs. Open
**http://127.0.0.1:5000** in a browser.

## Demo logins

| Username   | Password    | Role  |
|------------|-------------|-------|
| `admin`    | `admin123`  | Admin |
| `m.arif`   | `staff123`  | IS Staff (Network) |
| `s.ahmed`  | `staff123`  | IS Staff (SAP) |
| `b.javed`  | `staff123`  | IS Staff (Support) |
| `hassanat` | `intern123` | End user |

## Project structure

```
FFC_ICT_Helpdesk_System/
├── app.py                 # Flask routes / application logic
├── db.py                  # SQLite schema + demo data seeding
├── requirements.txt
├── static/
│   ├── style.css           # Full stylesheet (navy/gold theme)
│   └── chart.min.js        # Vendored Chart.js (works offline)
└── templates/
    ├── base.html
    ├── login.html
    ├── dashboard.html
    ├── tickets.html
    ├── ticket_form.html
    ├── ticket_detail.html
    ├── assets.html
    ├── asset_form.html
    └── asset_detail.html
```

## Resetting the demo data

Delete `ffc_helpdesk.db` and restart the app — it will be recreated and
reseeded automatically.

## Notes on production use

This project is built to be a clear, readable reference implementation
suitable for an internship/academic submission and for small-scale real
use. Before any real deployment at FFC, it should go through the
organisation's normal IT governance process — see the "Security &
Production Considerations" section of the documentation for the specific
items to address (authentication hardening, HTTPS, a production WSGI
server, integration with the existing Active Directory/domain instead of
a local user table, and formal input validation).
