"""
db.py
Database access layer for the FFC ICT Helpdesk & Asset Management System.

Uses Python's built-in sqlite3 module (no external DB dependency) so the
project can run anywhere Python 3 is installed.
"""

import sqlite3
import os
from datetime import datetime, timedelta
from werkzeug.security import generate_password_hash

DB_PATH = os.path.join(os.path.dirname(__file__), "ffc_helpdesk.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    full_name     TEXT NOT NULL,
    role          TEXT NOT NULL CHECK(role IN ('admin', 'staff', 'user')),
    department    TEXT,
    created_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS categories (
    id   INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL
);

CREATE TABLE IF NOT EXISTS assets (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    asset_tag       TEXT UNIQUE NOT NULL,
    name            TEXT NOT NULL,
    category_id     INTEGER NOT NULL,
    ip_address      TEXT,
    location        TEXT,
    status          TEXT NOT NULL CHECK(status IN ('Active','In Repair','Retired','Spare')),
    purchase_date   TEXT,
    warranty_expiry TEXT,
    assigned_to     TEXT,
    notes           TEXT,
    FOREIGN KEY (category_id) REFERENCES categories(id)
);

CREATE TABLE IF NOT EXISTS tickets (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    subject          TEXT NOT NULL,
    description      TEXT NOT NULL,
    category_id      INTEGER NOT NULL,
    priority         TEXT NOT NULL CHECK(priority IN ('Low','Medium','High','Critical')),
    status           TEXT NOT NULL CHECK(status IN ('Open','In Progress','Resolved','Closed')),
    requester_name   TEXT NOT NULL,
    requester_dept   TEXT,
    assigned_to      TEXT,
    asset_id         INTEGER,
    created_at       TEXT NOT NULL,
    resolved_at      TEXT,
    resolution_notes TEXT,
    FOREIGN KEY (category_id) REFERENCES categories(id),
    FOREIGN KEY (asset_id) REFERENCES assets(id)
);

CREATE TABLE IF NOT EXISTS ticket_comments (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    ticket_id  INTEGER NOT NULL,
    author     TEXT NOT NULL,
    comment    TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY (ticket_id) REFERENCES tickets(id)
);
"""


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db(seed=True):
    fresh = not os.path.exists(DB_PATH)
    conn = get_conn()
    conn.executescript(SCHEMA)
    conn.commit()
    if fresh and seed:
        _seed(conn)
    conn.close()


def _seed(conn):
    now = datetime.now()

    categories = ["Network", "Hardware", "SAP / ERP", "Software", "Access & Domain",
                  "Printer", "Server / Infrastructure", "Security"]
    conn.executemany("INSERT INTO categories (name) VALUES (?)", [(c,) for c in categories])
    conn.commit()
    cat_ids = {row["name"]: row["id"] for row in conn.execute("SELECT id, name FROM categories")}

    users = [
        ("admin", "admin123", "System Administrator", "admin", "Information Systems"),
        ("m.arif", "staff123", "Muhammad Arif", "staff", "Information Systems - Network"),
        ("s.ahmed", "staff123", "Saad Ahmed", "staff", "Information Systems - SAP"),
        ("b.javed", "staff123", "Bilal Javed", "staff", "Information Systems - Support"),
        ("hassanat", "intern123", "Hassanat Ali Moazzam", "user", "IS Internee"),
    ]
    for uname, pwd, full, role, dept in users:
        conn.execute(
            "INSERT INTO users (username, password_hash, full_name, role, department, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (uname, generate_password_hash(pwd), full, role, dept, now.isoformat()),
        )
    conn.commit()

    assets = [
        ("SRV-DB-01", "SAP Database Server", "Server / Infrastructure", "10.202.10.11", "Server Room, Goth Machhi", "Active", "2022-03-01", "2027-03-01", "IS Department", "Primary SAP HANA DB host"),
        ("SRV-APP-02", "SAP Application Server", "Server / Infrastructure", "10.202.10.12", "Server Room, Goth Machhi", "Active", "2022-03-01", "2027-03-01", "IS Department", "SAP application layer"),
        ("SW-CORE-01", "Core Network Switch", "Network", "10.202.1.1", "Server Room, Goth Machhi", "Active", "2021-06-15", "2026-06-15", "Network Team", "Cisco core switch"),
        ("FW-01", "Perimeter Firewall", "Security", "10.202.1.254", "Server Room, Goth Machhi", "Active", "2023-01-10", "2028-01-10", "Network Team", "Cisco firewall - internet edge"),
        ("NAS-DR-01", "DR Site NAS Storage", "Server / Infrastructure", "10.203.10.5", "DR Site", "Active", "2023-05-01", "2028-05-01", "Network Team", "120 TB usable capacity"),
        ("PR-ADMIN-04", "HP LaserJet - Admin Block", "Printer", "10.202.5.40", "Admin Block, Ground Floor", "Active", "2021-11-20", "2024-11-20", "Admin Dept", "Warranty expired - monitor closely"),
        ("PC-IT-011", "Dell OptiPlex - IT Helpdesk", "Hardware", "10.202.5.11", "IT Office", "Active", "2023-08-01", "2026-08-01", "IT Helpdesk", ""),
        ("PC-QHSE-02", "Dell Desktop - QHSE Dept", "Hardware", "10.202.6.22", "QHSE Building", "In Repair", "2020-02-14", "2023-02-14", "QHSE Dept", "Motherboard fault reported"),
        ("AP-PLANT-07", "Wireless Access Point - Plant Area 2", "Network", "10.202.2.17", "Plant-II, Near BCR-II", "Active", "2022-09-01", "2025-09-01", "Network Team", ""),
        ("CCTV-SRV-01", "CCTV NVR Server", "Security", "10.202.9.5", "Server Room, Goth Machhi", "Active", "2022-01-15", "2027-01-15", "Security Dept", "Manages plant CCTV feed"),
    ]
    for row in assets:
        name_cat = row[2]
        conn.execute(
            "INSERT INTO assets (asset_tag, name, category_id, ip_address, location, status, "
            "purchase_date, warranty_expiry, assigned_to, notes) VALUES (?,?,?,?,?,?,?,?,?,?)",
            (row[0], row[1], cat_ids[name_cat], row[3], row[4], row[5], row[6], row[7], row[8], row[9]),
        )
    conn.commit()

    def days_ago(n):
        return (now - timedelta(days=n)).isoformat()

    tickets = [
        ("SAP login fails after password reset", "User unable to log into SAP GUI after IS reset the domain password.",
         "SAP / ERP", "High", "Resolved", "Ayesha Noor", "Finance", "Saad Ahmed", None, days_ago(9), days_ago(9), "Cleared cached SAP logon ticket; reset SSO mapping."),
        ("No network connectivity - Plant-II office", "Entire office block on Plant-II lost network access.",
         "Network", "Critical", "Resolved", "Waqas Iqbal", "Plant-II Operations", "Muhammad Arif", "AP-PLANT-07", days_ago(7), days_ago(7), "Access point AP-PLANT-07 rebooted after firmware hang."),
        ("Printer not printing - Admin Block", "HP LaserJet in admin block shows offline status.",
         "Printer", "Medium", "In Progress", "Farah Latif", "Admin", "Bilal Javed", "PR-ADMIN-04", days_ago(2), None, None),
        ("New employee - domain account request", "Please create a domain account and email for new joiner in QHSE.",
         "Access & Domain", "Medium", "Open", "QHSE Manager", "QHSE", None, None, days_ago(1), None, None),
        ("SAP MM module - GRN posting error", "Error message when posting Goods Receipt Note in MM module.",
         "SAP / ERP", "High", "In Progress", "Imran Sheikh", "Stores", "Saad Ahmed", None, days_ago(3), None, None),
        ("Laptop running very slow", "Laptop takes 10+ minutes to boot and is unusable for SAP work.",
         "Hardware", "Low", "Open", "Nadia Khan", "HR", None, None, days_ago(1), None, None),
        ("CCTV feed down - Server Room camera", "Camera covering the server room entrance shows no feed.",
         "Security", "High", "Resolved", "Security Desk", "Security", "Muhammad Arif", "CCTV-SRV-01", days_ago(14), days_ago(13), "Replaced faulty PoE cable to camera."),
        ("Request: VPN access for remote SAP work", "Need VPN access approved to work on SAP reports from home.",
         "Access & Domain", "Medium", "Closed", "Kamran Yousaf", "Finance", "Muhammad Arif", None, days_ago(20), days_ago(18), "VPN profile created and tested successfully."),
        ("Desktop won't power on - QHSE", "Desktop completely dead, no lights, no boot.",
         "Hardware", "Medium", "In Progress", "QHSE Officer", "QHSE", "Bilal Javed", "PC-QHSE-02", days_ago(5), None, None),
        ("Firewall blocking vendor VC software", "Video conferencing software with foreign vendor is being blocked.",
         "Security", "High", "Open", "Procurement Manager", "Procurement", None, "FW-01", days_ago(1), None, None),
    ]
    for row in tickets:
        conn.execute(
            "INSERT INTO tickets (subject, description, category_id, priority, status, requester_name, "
            "requester_dept, assigned_to, asset_id, created_at, resolved_at, resolution_notes) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
            (
                row[0], row[1], cat_ids[row[2]], row[3], row[4], row[5], row[6], row[7],
                _asset_id(conn, row[8]) if row[8] else None,
                row[9], row[10], row[11],
            ),
        )
    conn.commit()


def _asset_id(conn, asset_tag):
    row = conn.execute("SELECT id FROM assets WHERE asset_tag = ?", (asset_tag,)).fetchone()
    return row["id"] if row else None


if __name__ == "__main__":
    init_db()
    print(f"Database initialised at {DB_PATH}")
